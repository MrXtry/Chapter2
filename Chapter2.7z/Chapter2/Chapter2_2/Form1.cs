﻿using System;
using System.ComponentModel;
using System.Threading;
using System.Windows.Forms;

namespace Chapter2_2
{
    public partial class Form1 : Form
    {
        private BackgroundWorker worker;
        //MyProgressBar pb;
        static double DoIntensiveCalculation()
        {
            
            // We are simulating intensiv calculations
            // by doing nonsens divisions
            double result = 100000000d;
            var maxValue = Int32.MaxValue;
            for (int i = 1; i < maxValue; i++)
            {
               
                result /= i;
            }
            return result + 10d;

        }
        public Form1()
        {
            worker = new BackgroundWorker();
            worker.WorkerReportsProgress = true;
            worker.WorkerSupportsCancellation = true;
            worker.DoWork += worker_DoWork;
            worker.RunWorkerCompleted += worker_RunWorkerCompleted;
            worker.ProgressChanged += new ProgressChangedEventHandler(Worker_ProgressChanged);
            InitializeComponent();
           
            //MessageBox.Show("Thread Id: " + Thread.CurrentThread.ManagedThreadId.ToString());
        }

        void CancelProcess(object sender, EventArgs e)
        {
            worker.CancelAsync();
        }
        //  
        private void worker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled == true)
            {
                resultLabel.Text = "Canceled!";
            }
            else if (e.Error != null)
            {
                resultLabel.Text = "Error: " + e.Error.Message;
            }
            else
            {
                resultLabel.Text = "Done!";
            }
            btnRun.Enabled = true;
           
        }

        private void worker_DoWork(object sender, DoWorkEventArgs e)
        {
            //MessageBox.Show("Thread id: " + Thread.CurrentThread.ManagedThreadId.ToString());
            double result = 100000000d;
           
            var maxValue = short.MaxValue * 100;
            for (int i = 1; i < maxValue; i++)
            {
                if (worker.CancellationPending == true)
                {
                    e.Cancel = true;
                    break;
                }
                else
                {
                    
                        result = (i * 100) / maxValue;
                        worker.ReportProgress((i * 100) / maxValue);
                  
                }
            }
            e.Result = result;
            //e.Result = DoIntensiveCalculation();
        }
        //The ProgressChanged event handler executes on the thread that created the BackgroundWorker.
        private void Worker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            //pb.ProgressText = e.ProgressPercentage.ToString();
            progressBar1.Value = e.ProgressPercentage;
        }

        private void btnRun_Click(object sender, EventArgs e)
        {
            
            //pb = new MyProgressBar();
            //pb.Cancel += CancelProcess;
            if (!worker.IsBusy)
            {
                //progressBar1.Value = 0;
                resultLabel.Text = "Working";
                worker.RunWorkerAsync();
                btnRun.Enabled = false;
                //pb.ShowDialog();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            worker.CancelAsync();
        }
    }
}
