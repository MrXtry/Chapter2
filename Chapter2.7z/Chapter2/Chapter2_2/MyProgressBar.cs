﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Chapter2_2
{
    public partial class MyProgressBar : Form
    {
        public MyProgressBar()
        {
            InitializeComponent();
        }
        public string ProgressText
        {
            set
            {
                this.label1.Text = value;
            }
            get { return this.label1.Text; }
        }

        public int ProgressValue
        {
            set
            {
                this.progressBar1.Value = value;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Cancel(sender, e);
        }

        public event EventHandler Cancel = delegate { };
    }
}
