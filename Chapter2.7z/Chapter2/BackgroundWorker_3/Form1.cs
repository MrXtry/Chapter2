﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BackgroundWorker_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        void CancelProcess(object sender, EventArgs e)
        {
            backgroundWorker1.CancelAsync();
        }
        //  
        private void worker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled == true)
            {
                resultLabel.Text = "Canceled!";
            }
            else if (e.Error != null)
            {
                resultLabel.Text = "Error: " + e.Error.Message;
            }
            else
            {
                resultLabel.Text = "Done!";
            }
            btnRun.Enabled = true;
            //Thread.Sleep(5000);
            //pb.Close();
        }

        private void worker_DoWork(object sender, DoWorkEventArgs e)
        {
            double result = 100000000d;
            var maxValue = int.MaxValue;
            //var maxValue = 10000000;
            for (int i = 1; i < maxValue; i++)
            {
                if (backgroundWorker1.CancellationPending == true)
                {
                    e.Cancel = true;
                    //btnRun.Enabled = true;
                    break;
                }
                else
                {
                    result /= i;
                    backgroundWorker1.ReportProgress((i * 100) / maxValue);
                   
                }
            }
            e.Result = result;
        }
        //The ProgressChanged event handler executes on the thread that created the BackgroundWorker.
        private void Worker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            progressBar1.Value = e.ProgressPercentage;
        }

        private void btnRun_Click(object sender, EventArgs e)
        {
            //pb = new MyProgressBar();
            //pb.Cancel += CancelProcess;
            if (!backgroundWorker1.IsBusy)
            {
                //progressBar1.Value = 0;
                resultLabel.Text = "Working";
                backgroundWorker1.RunWorkerAsync();
                btnRun.Enabled = false;
                //pb.ShowDialog();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            backgroundWorker1.CancelAsync();
        }
    }
}
