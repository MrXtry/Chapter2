﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Chapter2_1
{
    class Program
    {
        static double resultFromThreadPool = 0d;
        static double ReadDataFromIO()
        {
            Thread.Sleep(3000);
            return 10d;
        }
       
        static double DoIntensiveCalculation()
        {
            // We are simulating intensiv calculations
            // by doing nonsens divisions
            double result = 10000000d;
            var maxValue = int.MaxValue;
            for (int i = 1; i < maxValue; i++)
            {
              
                result /= i;
            }
            return result + 10d;

        }
        // TaskInfo holds state information for a task that will be
        // executed by a ThreadPool thread.
        public class TaskInfo
        {
            // State information for the task.  These members
            // can be implemented as read-only properties, read/write
            // properties with validation, and so on, as required.
            public string fileName;
            public int index;

            // Public constructor provides an easy way to supply all
            // the information needed for the task.
            public TaskInfo(string text, int number)
            {
                fileName = text;
                index = number;
            }
        }
        // This thread procedure performs the task.
        static void ThreadProc(Object stateInfo)
        {
            // We receive the threadInfo as an uncasted object.
            // Use the 'as' operator to cast it to ThreadInfo.
            TaskInfo threadInfo = stateInfo as TaskInfo;
            string fileName = threadInfo.fileName;
            int index = threadInfo.index;
            // No state object was passed to QueueUserWorkItem, so stateInfo is null.
            Console.WriteLine("Hello from the thread pool.");
        }
        static void Main(string[] args)
        {
            
            int workerThreads;
            int portThreads;

            ThreadPool.GetMaxThreads(out workerThreads, out portThreads);
            Console.WriteLine("\nMaximum worker threads: \t{0}" +
                "\nMaximum completion port threads: {1}",
                workerThreads, portThreads);
            
            ThreadPool.QueueUserWorkItem((s) =>
            {
                resultFromThreadPool += ReadDataFromIO();
               
            });
            // Pass these values to the thread.
            //TaskInfo threadInfo = new TaskInfo("file.txt", 4);
            //ThreadPool.QueueUserWorkItem(new WaitCallback(ThreadProc), threadInfo);
            
           
            Console.WriteLine("The resultFromThreadPool is {0}", resultFromThreadPool);
            double resultFromMainThread = DoIntensiveCalculation();
            
            // Wait for the thread to finish
            // Excercise: we will need a way to indicate
            // when the thread from thread pool finished the execusion
            // We can get a problem here. What?
            // Which Thread is completed first?
            
            Console.WriteLine("The resultFromMainThread is {0}", resultFromMainThread);

            Console.WriteLine("The total result is {0}", resultFromThreadPool + resultFromMainThread);

            Console.WriteLine("Press any key to exit the program");
            Console.ReadKey();

        }
    }
}


//var resetEvent = new AutoResetEvent(false);