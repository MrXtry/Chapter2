﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UpdateUiElement
{
    public partial class Form1 : Form
    {
        public static BackgroundWorker worker;
        private readonly SynchronizationContext _syncContext;
        static double DoIntensiveCalculation()
        {
            // We are simulating intensiv calculations
            // by doing nonsens divisions
            double result = 100000000d;
            var maxValue = int.MaxValue;
            for (int i = 1; i < maxValue; i++)
            {
                //Thread.Sleep(1);
                result /= i;
            }
            return result + 10d;

        }
        public Form1()
        {
            InitializeComponent();
            _syncContext = SynchronizationContext.Current;
            worker = new BackgroundWorker();
            worker.DoWork += worker_DoWork;
            worker.RunWorkerCompleted += worker_RunWorkerCompleted;
        }
        public SynchronizationContext GetSyncContext()
        {
            return _syncContext;
            
        }
        //  
        private void worker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (this.InvokeRequired)
            {
                this.Invoke(new Action<string>(UpdateLabel),
                    e.Result.ToString());
                //In WPF
                //this.Dispatcher.Invoke(() => lblResult.Text = e.Result.ToString());
            }
            else
                UpdateLabel(e.Result.ToString());
           
            
        }

        private void UpdateLabel(string text)
        {
            lblResult.Text = text;
        }

        //private void worker_DoWork(object sender, DoWorkEventArgs e)
        //{
        //    e.Result = DoIntensiveCalculation();
        //}
        private void worker_DoWork(object sender, DoWorkEventArgs e)
        {
            double result = 1d;
            var maxValue = short.MaxValue * 100;
            
            for (int i = 1; i < maxValue; i++)
            {
                result += 1;
                if (i % 100 == 0)
                {
                    if (this.InvokeRequired)
                    {
                        //Executes the specified delegate, on the thread that owns the control's underlying
                        //window handle, with the specified list of arguments.
                        this.Invoke(new Action<string>(UpdateLabel),
                            result.ToString());
                        //In WPF
                        //this.Dispatcher.Invoke(() => lblResult.Text = e.Result.ToString());
                    }
                    else
                        UpdateLabel(result.ToString());
                }
            }
            e.Result = result;

        }

        private void btnRun_Click(object sender, EventArgs e)
        {
            if (!worker.IsBusy)
            {
                lblResult.Text = "";
                worker.RunWorkerAsync();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AnotherThread.StartThreadNow(this);
            
        }

        public void UpdateLableWithSyncContext(string str)
        {
            anotherThreadLbl.Text = str;
        }

        public void UpdateLableWithInvoke(string str)
        {
            if (this.InvokeRequired)
            {
                this.Invoke(new Action<string>(UpdateLabel2),
                    str);
            }
            else
                UpdateLabel2(str);
            
        }

        private void UpdateLabel2(string text)
        {
            anotherThreadLbl.Text = text;
        }
    }
}
