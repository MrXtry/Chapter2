﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace UpdateUiElement
{
    class AnotherThread
    {
        static Form1 fr;
        public static void StartThreadNow(Form1 form)
        {
            fr = form;
            Thread t = new Thread(LongWork);
            t.Start();
        }
      
            //Update the lable using Invoke calling
        public static void LongWork()
        {

            // Perform a long running work...
            for (var i = 0; i < 10; i++)
            {
                Task.Delay(500).Wait();
                fr.UpdateLableWithInvoke(i.ToString());
            }
        }

        //Update the lable using SynchronizationContext
        //public static void LongWork()
        //{

        //    // Perform a long running work...
        //    for (var i = 0; i < 10; i++)
        //    {
        //        Task.Delay(500).Wait();
        //        fr.GetSyncContext().Post(o => fr.UpdateLableWithSyncContext(i.ToString()), null);
        //    }
        //}


    }
}
